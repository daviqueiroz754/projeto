<?php
session_start();

if(!isset($_SESSION["produtosCarrinho"])){

  $_SESSION["produtosCarrinho"] = array();
}





?>
